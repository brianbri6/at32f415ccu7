#include "Arduino.h"
extern "C" void SystemInit(void) {}
extern "C" void init(void) {}
int main(void) {
  SystemInit();
  init();
  setup();
  while (1) loop();
}
