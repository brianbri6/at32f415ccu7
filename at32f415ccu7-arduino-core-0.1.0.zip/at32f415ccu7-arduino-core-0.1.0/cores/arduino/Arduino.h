#pragma once
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
void init(void);
void SystemInit(void);
#ifdef __cplusplus
}
void setup(void);
void loop(void);
#endif
