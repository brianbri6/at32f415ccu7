#include <stdint.h>

/*
  AT32F415CCU7 / ILI9486-style 8-bit parallel LCD test
  Based on the working "native top-fill fix" bare-metal build.

  Pin mapping:
    LCD D0..D7 -> PA0..PA7
    Backlight  -> PA15
    LCD RESET  -> PB4
    LCD WR     -> PC13
    LCD RS/DC  -> PC15

  Notes:
  - This sketch uses direct register writes.
  - It is intended for an AT32F4 Arduino core, compiled in Arduino IDE,
    then flashed with OpenOCD.
*/

#define IOMUX_BASE        0x40010000u
#define GPIOA_BASE        0x40010800u
#define GPIOB_BASE        0x40010C00u
#define GPIOC_BASE        0x40011000u
#define CRM_BASE          0x40021000u

#define REG32(addr) (*(volatile uint32_t *)(uintptr_t)(addr))
#define BIT(n) (1u << (n))

#define CRM_APB2EN        REG32(CRM_BASE + 0x18u)
#define IOMUX_MAPR        REG32(IOMUX_BASE + 0x04u)
#define GPIO_ODT(base)    REG32((base) + 0x0Cu)
#define GPIO_SCR(base)    REG32((base) + 0x10u)
#define GPIO_CLR(base)    REG32((base) + 0x14u)

#define CRM_APB2EN_IOMUXEN BIT(0)
#define CRM_APB2EN_IOPAEN  BIT(2)
#define CRM_APB2EN_IOPBEN  BIT(3)
#define CRM_APB2EN_IOPCEN  BIT(4)

#define LCD_DATA_PORT GPIOA_BASE /* PA0..PA7 */
#define LCD_BL_PORT   GPIOA_BASE /* PA15 */
#define LCD_BL_PIN    15u
#define LCD_RST_PORT  GPIOB_BASE /* PB4 */
#define LCD_RST_PIN   4u
#define LCD_WR_PORT   GPIOC_BASE /* PC13 */
#define LCD_WR_PIN    13u
#define LCD_RS_PORT   GPIOC_BASE /* PC15 */
#define LCD_RS_PIN    15u

#define LCD_W 480u
#define LCD_H 320u
#define MADCTL_ILI9486_LANDSCAPE 0xA8u /* MY | MV | BGR */

static void delay_cycles(volatile uint32_t n) { while (n--) __asm__ volatile ("nop"); }
static void delay_ms(uint32_t ms) { while (ms--) delay_cycles(8000); }

static void gpio_set_output_pp_50m(uint32_t base, uint32_t pin) {
  volatile uint32_t *cfg = (pin < 8u) ? (volatile uint32_t *)(uintptr_t)(base + 0x00u)
                                      : (volatile uint32_t *)(uintptr_t)(base + 0x04u);
  uint32_t shift = (pin & 7u) * 4u;
  uint32_t v = *cfg;
  v &= ~(0xFu << shift);
  v |=  (0x3u << shift);
  *cfg = v;
}

static void gpio_write(uint32_t base, uint32_t pin, int high) {
  if (high) GPIO_SCR(base) = BIT(pin);
  else      GPIO_CLR(base) = BIT(pin);
}

static void gpio_write_port_low8(uint32_t base, uint8_t value) {
  uint32_t odt = GPIO_ODT(base);
  odt &= ~0xFFu;
  odt |= value;
  GPIO_ODT(base) = odt;
}

static void bus_idle(void) {
  gpio_write(LCD_WR_PORT, LCD_WR_PIN, 1);
  gpio_write(LCD_RS_PORT, LCD_RS_PIN, 1);
  gpio_write(LCD_RST_PORT, LCD_RST_PIN, 1);
  gpio_write(LCD_BL_PORT, LCD_BL_PIN, 0);
  gpio_write_port_low8(LCD_DATA_PORT, 0x00);
}

static void lcd_wr_pulse(void) {
  gpio_write(LCD_WR_PORT, LCD_WR_PIN, 0);
  __asm__ volatile ("nop\n nop\n nop\n nop\n nop\n nop\n nop\n nop");
  gpio_write(LCD_WR_PORT, LCD_WR_PIN, 1);
}

static void lcd_bus_write(uint8_t value, int is_data) {
  gpio_write(LCD_RS_PORT, LCD_RS_PIN, is_data ? 1 : 0);
  gpio_write_port_low8(LCD_DATA_PORT, value);
  lcd_wr_pulse();
}

static void lcd_cmd(uint8_t v)  { lcd_bus_write(v, 0); }
static void lcd_data(uint8_t v) { lcd_bus_write(v, 1); }

static void lcd_reset(void) {
  gpio_write(LCD_RST_PORT, LCD_RST_PIN, 1);
  delay_ms(20);
  gpio_write(LCD_RST_PORT, LCD_RST_PIN, 0);
  delay_ms(40);
  gpio_write(LCD_RST_PORT, LCD_RST_PIN, 1);
  delay_ms(120);
}

static void backlight_set(int on) { gpio_write(LCD_BL_PORT, LCD_BL_PIN, on ? 1 : 0); }

static void backlight_blink(uint32_t count, uint32_t on_ms, uint32_t off_ms) {
  for (uint32_t i = 0; i < count; ++i) {
    backlight_set(1); delay_ms(on_ms);
    backlight_set(0); delay_ms(off_ms);
  }
  backlight_set(1);
}

static void lcd_set_window(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1) {
  lcd_cmd(0x2A);
  lcd_data((uint8_t)(x0 >> 8)); lcd_data((uint8_t)x0);
  lcd_data((uint8_t)(x1 >> 8)); lcd_data((uint8_t)x1);
  lcd_cmd(0x2B);
  lcd_data((uint8_t)(y0 >> 8)); lcd_data((uint8_t)y0);
  lcd_data((uint8_t)(y1 >> 8)); lcd_data((uint8_t)y1);
  lcd_cmd(0x2C);
}

static void lcd_push_color565(uint16_t c) {
  lcd_data((uint8_t)(c >> 8));
  lcd_data((uint8_t)c);
}

static void lcd_fill_solid_565(uint16_t c) {
  lcd_set_window(0, 0, LCD_W - 1, LCD_H - 1);
  for (uint32_t i = 0; i < (uint32_t)LCD_W * (uint32_t)LCD_H; ++i) lcd_push_color565(c);
}

static void lcd_fill_rect_565(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t c) {
  if (x >= LCD_W || y >= LCD_H || w == 0 || h == 0) return;
  if ((uint32_t)x + w > LCD_W) w = LCD_W - x;
  if ((uint32_t)y + h > LCD_H) h = LCD_H - y;
  lcd_set_window(x, y, x + w - 1, y + h - 1);
  for (uint32_t i = 0; i < (uint32_t)w * (uint32_t)h; ++i) lcd_push_color565(c);
}

static uint8_t glyph_row(char c, uint8_t row) {
  switch (c) {
    case 'H': { static const uint8_t g[7]={0x11,0x11,0x11,0x1F,0x11,0x11,0x11}; return g[row]; }
    case 'E': { static const uint8_t g[7]={0x1F,0x10,0x10,0x1E,0x10,0x10,0x1F}; return g[row]; }
    case 'L': { static const uint8_t g[7]={0x10,0x10,0x10,0x10,0x10,0x10,0x1F}; return g[row]; }
    case 'O': { static const uint8_t g[7]={0x0E,0x11,0x11,0x11,0x11,0x11,0x0E}; return g[row]; }
    case 'W': { static const uint8_t g[7]={0x11,0x11,0x11,0x15,0x15,0x15,0x0A}; return g[row]; }
    case 'R': { static const uint8_t g[7]={0x1E,0x11,0x11,0x1E,0x14,0x12,0x11}; return g[row]; }
    case 'D': { static const uint8_t g[7]={0x1E,0x11,0x11,0x11,0x11,0x11,0x1E}; return g[row]; }
    case '!': { static const uint8_t g[7]={0x04,0x04,0x04,0x04,0x04,0x00,0x04}; return g[row]; }
    case ' ': return 0x00;
    default: return 0x00;
  }
}

static void lcd_draw_char_scaled(uint16_t x, uint16_t y, char c, uint8_t scale, uint16_t fg, uint16_t bg) {
  for (uint8_t row = 0; row < 7; ++row) {
    uint8_t bits = glyph_row(c, row);
    for (uint8_t col = 0; col < 5; ++col) {
      int on = (bits >> (4 - col)) & 1u;
      lcd_fill_rect_565(x + col * scale, y + row * scale, scale, scale, on ? fg : bg);
    }
    lcd_fill_rect_565(x + 5 * scale, y + row * scale, scale, scale, bg);
  }
  lcd_fill_rect_565(x, y + 7 * scale, 6 * scale, scale, bg);
}

static void lcd_draw_text_scaled(uint16_t x, uint16_t y, const char *s, uint8_t scale, uint16_t fg, uint16_t bg) {
  while (*s) {
    lcd_draw_char_scaled(x, y, *s++, scale, fg, bg);
    x += 6u * scale;
  }
}

static void init_ili9486_565(uint8_t madctl) {
  lcd_reset();
  lcd_cmd(0x01);
  delay_ms(120);

  lcd_cmd(0xF1);
  lcd_data(0x36); lcd_data(0x04); lcd_data(0x00); lcd_data(0x3C); lcd_data(0x0F); lcd_data(0x8F);

  lcd_cmd(0xF2);
  lcd_data(0x18); lcd_data(0xA3); lcd_data(0x12); lcd_data(0x02);
  lcd_data(0xB2); lcd_data(0x12); lcd_data(0xFF); lcd_data(0x10); lcd_data(0x00);

  lcd_cmd(0xF8);
  lcd_data(0x21); lcd_data(0x04);

  lcd_cmd(0xF9);
  lcd_data(0x00); lcd_data(0x08);

  lcd_cmd(0x36);
  lcd_data(madctl);

  lcd_cmd(0x3A);
  lcd_data(0x55); /* RGB565 */

  lcd_cmd(0xB4);
  lcd_data(0x02);

  lcd_cmd(0xB6);
  lcd_data(0x02); lcd_data(0x22);

  lcd_cmd(0xC1);
  lcd_data(0x41);

  lcd_cmd(0xC5);
  lcd_data(0x00); lcd_data(0x18);

  lcd_cmd(0xE0);
  lcd_data(0x0F); lcd_data(0x1F); lcd_data(0x1C); lcd_data(0x0C); lcd_data(0x0F); lcd_data(0x08); lcd_data(0x48); lcd_data(0x98);
  lcd_data(0x37); lcd_data(0x0A); lcd_data(0x13); lcd_data(0x04); lcd_data(0x11); lcd_data(0x0D); lcd_data(0x00);

  lcd_cmd(0xE1);
  lcd_data(0x0F); lcd_data(0x32); lcd_data(0x2E); lcd_data(0x0B); lcd_data(0x0D); lcd_data(0x05); lcd_data(0x47); lcd_data(0x75);
  lcd_data(0x37); lcd_data(0x06); lcd_data(0x10); lcd_data(0x03); lcd_data(0x24); lcd_data(0x20); lcd_data(0x00);

  lcd_cmd(0x11);
  delay_ms(120);
  lcd_cmd(0x29);
  delay_ms(20);
}

static void clock_and_gpio_init(void) {
  CRM_APB2EN |= CRM_APB2EN_IOMUXEN | CRM_APB2EN_IOPAEN | CRM_APB2EN_IOPBEN | CRM_APB2EN_IOPCEN;
  (void)CRM_APB2EN;

  uint32_t mapr = IOMUX_MAPR;
  mapr &= ~(7u << 24);
  mapr |=  (2u << 24); /* disable JTAG, keep SWD */
  IOMUX_MAPR = mapr;

  for (uint32_t pin = 0; pin <= 7; ++pin) gpio_set_output_pp_50m(GPIOA_BASE, pin);
  gpio_set_output_pp_50m(GPIOA_BASE, LCD_BL_PIN);
  gpio_set_output_pp_50m(GPIOB_BASE, LCD_RST_PIN);
  gpio_set_output_pp_50m(GPIOC_BASE, LCD_WR_PIN);
  gpio_set_output_pp_50m(GPIOC_BASE, LCD_RS_PIN);
  bus_idle();
}

static void show_hello_world(void) {
  lcd_fill_solid_565(0x0000);
  lcd_fill_rect_565(10, 10, LCD_W - 20, 10, 0xF800);
  lcd_fill_rect_565(10, LCD_H - 20, LCD_W - 20, 10, 0x001F);
  lcd_fill_rect_565(10, 10, 10, LCD_H - 20, 0xFFE0);
  lcd_fill_rect_565(LCD_W - 20, 10, 10, LCD_H - 20, 0x07E0);
  lcd_draw_text_scaled(72, 52, "HELLO", 8, 0xFFFF, 0x0000);
  lcd_draw_text_scaled(72, 170, "WORLD!", 7, 0xFFE0, 0x0000);
}

void setup() {
  clock_and_gpio_init();
  backlight_blink(3, 90, 90);
  init_ili9486_565(MADCTL_ILI9486_LANDSCAPE);
  backlight_set(1);
}

void loop() {
  lcd_fill_solid_565(0xF800); /* red */
  delay_ms(700);
  lcd_fill_solid_565(0x07E0); /* green */
  delay_ms(700);
  lcd_fill_solid_565(0x001F); /* blue */
  delay_ms(700);
  show_hello_world();
  delay_ms(2500);
}
