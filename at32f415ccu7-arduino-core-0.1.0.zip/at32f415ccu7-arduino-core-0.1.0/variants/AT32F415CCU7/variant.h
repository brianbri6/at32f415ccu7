#pragma once
#define VARIANT_MAINOSC 8000000U
