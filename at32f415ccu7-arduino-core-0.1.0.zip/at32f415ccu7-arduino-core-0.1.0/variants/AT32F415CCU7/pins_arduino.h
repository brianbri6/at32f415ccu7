#pragma once
#include <stdint.h>
#define PINS_COUNT           0
#define NUM_DIGITAL_PINS     0
#define NUM_ANALOG_INPUTS    0
