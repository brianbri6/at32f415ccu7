# AT32F415CCU7 Board Manager starter package

This is a starter Arduino platform package for a custom AT32F415CCU7 board.

What is included:
- `boards.txt` and `platform.txt`
- minimal core (`cores/arduino`)
- AT32F415CCU7 variant folder with linker script
- working LCD example sketch

What is *not* included yet:
- a tested upstream ARM GCC tool dependency definition for Boards Manager
- a bundled copy of the ArteryTek AT32F415 Firmware Library
- upload tooling integration inside Arduino IDE

## Add the ArteryTek AT32F415 Firmware Library
The upstream repository is:
https://github.com/ArteryTek/AT32F415_Firmware_Library

Suggested integration approach:
1. vendor selected startup/CMSIS/peripheral sources from the upstream repo into this package,
2. keep the BSD-3-Clause license and notices,
3. add include/library paths in `platform.txt`,
4. replace the minimal core with the upstream startup/system files as needed.

## Publish via Boards Manager
1. Zip this folder so the zip root contains **one folder only**.
2. Upload the zip to a GitHub release or other static URL.
3. Compute the ZIP's size and SHA-256 checksum.
4. Edit `package_brianb_at32f415_index.json` with the real URL, archive filename, size, and checksum.
5. Host the JSON file at a public HTTPS URL.
